import { Box, Container, Heading, Text } from '@chakra-ui/react'
import React from 'react'



const Dashboard = () => {
    const boxStyles = {
       p: "10px",
       bg: "purple.400",
       color: "#fff",
       m: "10px",
       textAlign: "center",
       filter: "blur(2px)",
       ":hover": {
        color: "#fff",
        bg: "black",
        filter: "blur(0px)",
        cursor: "pointer",
       }
    }
    return (
        <>
            <Container maxWidth="4xl" py={20}>
                Dashboard
                <Heading
                    my={30} p={10}
                >Chakra UI Components</Heading>
                <Text>Lorem ipsum dolor sit amet consectetur
                    adipisicing elit. Beatae, illum?</Text>
                <Text ml={30}
                    color="blue.500" fontWeight="bold"
                >Lorem ipsum dolor sit amet consectetur
                    adipisicing elit. Beatae, illum?</Text>

                <Box my={30} p={20} bg={"orange"}>
                    <Text
                        color={"white"}
                    >
                        This is a box component
                    </Text>
                </Box>

            </Container>
            {/* you can overwrite container using as */}
            <Container as={"section"}>
                <Box my={30} p={20} bg={"orangered"}>
                    <Text
                        color={"white"}
                    >
                        This is a contaner defined as section tag
                    </Text>
                </Box>
            </Container>
            {/* another way is doing prop sx */}
            <Box sx={boxStyles}>
                 this is prop "sx" when its styles is given by object
            </Box>
        </>
    )
}

export default Dashboard;