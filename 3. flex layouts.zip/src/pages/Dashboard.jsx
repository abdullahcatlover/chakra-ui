import { Box, Container, Heading, SimpleGrid, Spacer, Text } from '@chakra-ui/react'
import React from 'react'



const Dashboard = () => {
    
    return (
        <>
            <SimpleGrid p={"10px"} spacing={"10px"}  minChildWidth={"250px"}>
               <Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
               </Box>
               <Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
               </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box>

                 <Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
               </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box>

                 <Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
               </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box><Box bg={"White"} h={"200px"} border={"1px solid"}>
                 
                 </Box>
            </SimpleGrid>
        </>
    )
}

export default Dashboard;