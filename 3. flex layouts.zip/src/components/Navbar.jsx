import { Box, Button, Flex, HStack, 
    Heading, Spacer, Text} from "@chakra-ui/react";








const Navbar = () => {

    const navbarBaseStyle ={
        p: "10px",
        alignItems: "center",
    }


  return (
    <Flex as="nav" sx={navbarBaseStyle}>
        <Heading as="h1">Tasks</Heading>
        <Spacer />
        <HStack spacing={"20px"}>
        <Box bg={"gray.200"} p={"10px"}>M</Box>
        <Text>abdullah@gmail.dev</Text>
        <Button colorScheme="purple">Log Out</Button>
        </HStack>
    </Flex>
  )
}

export default Navbar;





//  this is test navbar
//const Navbar = () => {

//     const navbarBaseStyle ={
//         bg: "gray.200", 
//         justifyContent: "space-between",
//         wrap: "wrap",
//         gap: 2,
//     }
    
//   return (
//     <Flex sx={navbarBaseStyle}>
//         <Box w={150} h={50} bg={"red"}>1</Box>
//         <Box w={150} h={50} bg={"blue"}>2</Box>
//         <Box w={150} h={50} flexGrow={1} bg={"green"}>3</Box>
//         <Box w={150} h={50}  flexGrow={1} bg={"yellow"}>4</Box>
//     </Flex>
//   )
// }

// export default Navbar;